﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml;

using System.Threading;
using ProS_Assm;
using DevComponents.DotNetBar;
using DevComponents.DotNetBar.Controls;

namespace LPSP_OutPut
{
    public partial class Summary : DevComponents.DotNetBar.Office2007Form
    {
        DataSet OutDS = new DataSet();
                
        public progress myprogress;
        private string sourceTableName;

        public delegate DataTable[] ExcelRead();
        public void AddComplete(IAsyncResult result)
        {
            this.myprogress.SetChecked1();
        }
        public Summary()
        {
            InitializeComponent();
        }
        private void ReadOutFiles()
        {
            DataSet ds1 = new DataSet();
            ds1.ReadXml(UniVars.mOutFile + "_RST.xml");
            OutDS.Merge(ds1, true);
            DataSet ds2 = new DataSet();
            ds2.ReadXml(UniVars.mOutFile + "_GEN.xml");
            OutDS.Merge(ds2, true);
            DataSet ds3 = new DataSet();
            ds3.ReadXml(UniVars.mOutFile + "_MAP.xml");
            OutDS.Merge(ds3, true);

            this.TempletesRead();
            comboBoxEx1.Enabled = true;
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            Control.CheckForIllegalCrossThreadCalls = false;
            Application.EnableVisualStyles();
            this.Text = UniVars.mOutFile;
            textBoxX1.Text = UniVars.mOutFile;
            if (textBoxX1.Text.Trim() != "")
                ReadOutFiles();
        }

        public void progressB()
        {
            this.myprogress = new progress();
            myprogress.ShowDialog();
        }

        private string GetSysNameByID(string id)
        {
            DataTable dt=UniVars.InDS.Tables["系统表"];
            foreach(DataRow row in dt.Rows)
                if(row["节点ID"].ToString()==id)
                    return row["节点名称"].ToString();
            return null;
        }
        //根据模板ID返回基础表编号
        private string findOriginal(string s)
        {
            string ss = "";
            XmlDocument xmldoc = new XmlDocument();
            xmldoc.Load(Application.StartupPath + "\\TableViewConfig.xml");
            //得到顶层节点列表
            XmlNodeList topM = xmldoc.DocumentElement.ChildNodes;
            foreach (XmlNode element in topM)
            {
                if (element.Name.ToLower() == "templete")
                {
                    XmlNodeList nodelist = element.ChildNodes;
                    if (nodelist.Count > 0)
                    {
                        foreach (XmlNode el in nodelist)//读元素值
                        {
                            if (el.Name.ToLower().Equals("item") && el.Attributes["id"].Value.ToString().Trim().Equals(s))
                            {
                                XmlNodeList nodelistclon = el.ChildNodes;
                                if (nodelistclon.Count > 0)
                                {
                                    foreach (XmlNode ell in nodelistclon)
                                    {
                                        string str = "";
                                        if (ell.Name.ToLower().Equals("columns"))
                                        {
                                            str = ell.ChildNodes[0].Attributes["belongTableId"].Value.ToString().Trim();
                                            //MessageBox.Show(str);
                                            return str;
                                        }
                                        if (ell.Name.ToLower().Equals("rows"))
                                        {
                                            str = ell.ChildNodes[0].Attributes["belongTableId"].Value.ToString().Trim() + ell.ChildNodes[0].Attributes["refcodeId"].Value.ToString().Trim().Substring(0, 1);
                                            // MessageBox.Show(str);
                                            return str;
                                        }
                                    }
                                }

                            }
                        }
                    }
                }
            }
            return ss;
        }
        //加载标签
        private Boolean TempletesRead()
        {
            try
            {
                XmlDocument xmldoc = new XmlDocument();
                xmldoc.Load(Application.StartupPath + "\\TableViewConfig.xml");
                //得到顶层节点列表
                XmlNodeList topM = xmldoc.DocumentElement.ChildNodes;
                foreach (XmlNode element in topM)
                {
                    if (element.Name.ToLower() == "templete")
                    {
                        XmlNodeList nodelist = element.ChildNodes;
                        if (nodelist.Count > 0)
                        {
                            foreach (XmlNode el in nodelist)//读元素值
                            {
                                if (el.Name.ToLower() != "item")
                                    continue;
                                this.comboBoxEx1.Items.Add(el.Attributes["id"].Value.ToString().Trim() + "-" + el.Attributes["name"].Value.ToString());
                            }
                            break;
                        }
                    }
                }
                return true;
            }
            catch
            {
                return false;
            }

        }
        //重置combobox
        private void ComboboxReset()
        {
            comboBoxEx2.SelectedIndex = -1;
            comboBoxEx3.SelectedIndex = -1;
            comboBoxEx4.SelectedIndex = -1;
            comboBoxEx5.SelectedIndex = -1;
            comboBoxEx6.SelectedIndex = -1;
        }
        //让下拉列表框联动函数
        private void combChange(string s)
        {
            ComboboxReset();
            comboBoxEx2.Items.Clear();
            DataTable distinctValues = OutDS.Tables[s].DefaultView.ToTable(true, "Prj");
            foreach (DataRow row in distinctValues.Rows)
                comboBoxEx2.Items.Add(row[0].ToString());
            if (comboBoxEx2.Items.Count > 0)
            {
                comboBoxEx2.Items.Add("ALL");
                comboBoxEx2.SelectedIndex = 0;
            }
            switch (s)
            {
                case "PPL":
                case "PLD":
                case "ENS":
                case "ENG":
                case "TEC":
                case "TRK":
                    {
                        labelX4.Visible = false;
                        comboBoxEx7.Visible = false;

                        labelX6.Text = "系统及分区：";
                        labelX7.Text = "日类型：";
                        
                        //系统及分区
                        SysPart();

                        //日类型
                        if (s == "ENS" || s == "ENG" || s == "TEC")
                        {
                            dayPart1(comboBoxEx5);
                            if (s == "ENG")
                            {
                                //电站名称
                                labelX6.Text = "  电站名称：";
                                genPart(comboBoxEx3);
                            }

                        }
                        else
                            dayPart2(comboBoxEx5);
                    }
                    break;
                case "GEN":
                case "HST":
                    {
                        labelX4.Visible = true;
                        comboBoxEx7.Visible = true;
                       
                        labelX7.Text = "  月份：";
                        labelX4.Text = "日类型：";

                        if (s == "GEN")
                        {
                            //电站名称
                            labelX6.Text = "  电站名称：";
                            genPart(comboBoxEx3);
                        }
                        else
                        {
                            int index = Convert.ToInt32(comboBoxEx1.Text.Split(new Char[] { '-' })[0]) - 11;
                            labelX6.Text = "系统及分区：";
                            switch (index)
                            {
                                case 3:
                                    labelX6.Text = "联络线名称：";
                                    break;
                                case 4:
                                    labelX6.Text = "输电线名称：";
                                    break;
                                default:
                                    break;
                            }
                            linePart(comboBoxEx3,index);
                        }

                        //月份
                        comboBoxEx5.Items.Clear();
                        for (int i = 1; i <= 12; i++)
                            comboBoxEx5.Items.Add(i + "月");
                        comboBoxEx5.Items.Add("ALL");
                        if (comboBoxEx5.Items.Count > 0)
                            comboBoxEx5.SelectedIndex = 0;

                        //日类型
                        dayPart2(comboBoxEx7);                          

                    }
                    break;
                default:
                    {

                    }
                    break;


            }

        }

        private void updateRowWithFactor(DataTable dt, int rowIndex, string factor)
        {
            if (factor == "1")
                return;

            switch (sourceTableName)
            {
                case "PPL":
                case "PLD":
                case "ENS":
                case "ENG":
                case "TEC":
                case "TRK":
                    for (int x = 0; x < dt.Columns.Count; x++)
                    {
                        string[] columnPartNames = dt.Columns[x].ColumnName.Split(new string[] { "." }, StringSplitOptions.None);
                        if (columnPartNames[0] == "项  目")
                            continue;
                        if (dt.Rows[rowIndex][x].ToString().Trim()!="")
                            dt.Rows[rowIndex][x] = Convert.ToDouble(dt.Rows[rowIndex][x])*Convert.ToDouble(factor);
                    }
                    break;
                default:
                    break;
            }
        }
        //修改表的行名和列名
        private void changeName(DataTable dt, int x)
        {
            int m = 0;
            int n = 0;
            //更改列名
            for (int i = 0; i < dt.Columns.Count; i++)
            {
                string cName = dt.Columns[i].ColumnName;
                string[] arrStr1 = cName.Split(new string[] { "." }, StringSplitOptions.None);
                if (arrStr1[0] == "自定义")
                    dt.Columns[i].ColumnName = arrStr1[1].ToString();
                else
                {
                    string[] columnNameAndFactor = getColName(arrStr1[0], arrStr1[1]);
                    dt.Columns[i].ColumnName = columnNameAndFactor[0];
                    if (radioButton2.Checked)
                        if (columnNameAndFactor[1] != "1")
                            foreach (DataRow row in dt.Rows)
                                if(row[i].ToString().Trim()!="")
                                    row[i] = Convert.ToDouble(row[i]) * Convert.ToDouble(columnNameAndFactor[1]);
                }
            }
            if (sourceTableName == "GEN" || sourceTableName == "HST")
                return;
            //更改行名
            for (int j = 0; j < dt.Rows.Count; j++)
            {
                string cName1 = dt.Rows[j][x].ToString();
                string[] arrStr11 = cName1.Split(new string[] { "-" }, StringSplitOptions.None);


                if (arrStr11[0] == "自定义")
                    dt.Rows[j][x] = arrStr11[1].ToString();
                else if (checkBox1.Checked == false)
                {
                    string[] rowAndFactor = getRowNameAndFactor(arrStr11[0], arrStr11[1]);
                    dt.Rows[j][x] = rowAndFactor[0];
                    if (radioButton2.Checked)
                        updateRowWithFactor(dt, j, rowAndFactor[1]);
                }
                else
                {
                    string[] name = arrStr11[1].Split(new string[] { "." }, StringSplitOptions.None);
                    if (name.Length == 1)
                    {
                        string[] rowAndFactor = getRowNameAndFactor(arrStr11[0], arrStr11[1]);
                        dt.Rows[j][x] = convertInt(m) + "、" + rowAndFactor[0];
                        if (radioButton2.Checked)
                            updateRowWithFactor(dt, j, rowAndFactor[1]); n = 0;
                        m++;
                    }
                    else if (name.Length == 2)
                    {
                        n++;
                        string[] rowAndFactor = getRowNameAndFactor(arrStr11[0], arrStr11[1]);
                        dt.Rows[j][x] = "  " + n.ToString() + "." + rowAndFactor[0];
                        if (radioButton2.Checked)
                            updateRowWithFactor(dt, j, rowAndFactor[1]); n = 0;
                    }
                    else if (name.Length == 3)
                    {
                        string[] rowAndFactor = getRowNameAndFactor(arrStr11[0], arrStr11[1]);
                        dt.Rows[j][x] = "    " + rowAndFactor[0];
                        if (radioButton2.Checked)
                            updateRowWithFactor(dt, j, rowAndFactor[1]); n = 0;
                    }
                }
            }
        }
        private string[] getColName(string a, string b)
        {
            string[] returnStr = new string[2];
            XmlDocument xmldoc = new XmlDocument();
            xmldoc.Load(Application.StartupPath + "\\TableViewConfig.xml");
            //得到顶层节点列表
            XmlNodeList topM = xmldoc.DocumentElement.ChildNodes;
            foreach (XmlNode element in topM)
            {
                if (element.Name.ToLower() == "dictionary")
                {
                    XmlNodeList nodelist = element.ChildNodes;
                    if (nodelist.Count > 0)
                    {
                        foreach (XmlNode el in nodelist)//读元素值
                        {
                            String c = el.Name.ToString();
                            if (el.Name.ToLower() == "item" && el.Attributes["id"].Value.ToString().Equals(a))
                            {
                                XmlNodeList nl = el.ChildNodes;
                                foreach (XmlNode ex in nl)
                                {

                                    if (ex.Name.ToLower() == "columns")
                                    {
                                        XmlNodeList nx = ex.ChildNodes;
                                        foreach (XmlNode xx in nx)
                                        {
                                            if (b.Equals(xx.Attributes["id"].Value.ToString()))
                                            {
                                                returnStr[0] = xx.Attributes["name"].Value.ToString();
                                                if (xx.Attributes["Factor"] == null)
                                                    returnStr[1] = "1";
                                                else
                                                    returnStr[1] = xx.Attributes["Factor"].Value.ToString();
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return returnStr;
        }
        private string[] getRowNameAndFactor(string a, string b)
        {
            string[] returnStr =new string[2];
            returnStr[1] = "1";
            XmlDocument xmldoc = new XmlDocument();
            xmldoc.Load(Application.StartupPath + "\\TableViewConfig.xml");
            //得到顶层节点列表
            XmlNodeList topM = xmldoc.DocumentElement.ChildNodes;
            foreach (XmlNode element in topM)
            {
                if (element.Name.ToLower() == "dictionary")
                {
                    XmlNodeList nodelist = element.ChildNodes;
                    if (nodelist.Count > 0)
                    {
                        foreach (XmlNode el in nodelist)//读元素值
                        {
                            String c = el.Name.ToString();
                            if (el.Name.ToLower() == "item" && el.Attributes["id"].Value.ToString().Equals(a))
                            {
                                XmlNodeList nl = el.ChildNodes;
                                foreach (XmlNode ex in nl)
                                {

                                    if (ex.Name.ToLower() == "rows")
                                    {
                                        XmlNodeList nx = ex.ChildNodes;
                                        foreach (XmlNode xx in nx)
                                        {
                                            if (b.Equals(xx.Attributes["code"].Value.ToString()))
                                            {
                                                returnStr[0] = xx.Attributes["content"].Value.ToString();
                                                if(xx.Attributes["Factor"]!=null)
                                                    returnStr[1] = xx.Attributes["Factor"].Value.ToString();
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return returnStr;
        }
        private string convertInt(int d)
        {
            string tem = "";
            string[] chineseNum = new string[] { "一", "二", "三", "四", "五", "六", "七", "八", "九", "十" };
            string num = d.ToString();
            if (num.Length == 1)
            {
                tem = chineseNum[int.Parse(num)];
            }
            else if (num.Length == 2)
            {
                if (num[0] == '1')
                {
                    tem = "十" + chineseNum[int.Parse(num.Substring(1, 1))];
                }
                else
                {
                    tem = chineseNum[int.Parse(num.Substring(0, 1))] + "十" + chineseNum[int.Parse(num.Substring(1, 1))];
                }
            }
            return tem;
        }


        private string PrepareFilterString(string itemValue,string sID)
        {
            /*
             * 当ComboBox选中ALL时，itemValue等于ComboBox的每一项的值；
             * 否则，不适用itemValue。
             */
            string str = "";

            if (comboBoxEx2.Text == "ALL")
                str += "Prj = " + itemValue;
            else
                str += "Prj = " + comboBoxEx2.Text;

            if (comboBoxEx4.Text == "ALL")
                str += " and Yrs = " + itemValue;
            else
                str += " and Yrs = " + comboBoxEx4.Text;

            if (comboBoxEx6.Text == "ALL")
                str += " and Hyd = " + itemValue;
            else
                str += " and Hyd = " + comboBoxEx6.Text.Split(new string[] { "-" }, StringSplitOptions.None)[0];
            switch (sourceTableName)
            {
                case "PPL":
                case "PLD":
                case "ENS":
                case "ENG":
                case "TEC":
                case "TRK":
                    if (comboBoxEx3.Text == "ALL")
                        str += " and sID=" + itemValue;
                    else
                        str += " and sID=" + comboBoxEx3.Text.Split(new string[] { "-" }, StringSplitOptions.None)[0];
                    
                    if (comboBoxEx5.Text == "ALL")
                        str += " and dID=" + itemValue;
                    else
                        str += " and dID=" + comboBoxEx5.Text.Split(new string[] { "-" }, StringSplitOptions.None)[0];
                    break;
                case "GEN":
                case "HST":
                    if (comboBoxEx5.Text == "ALL")
                        str += " and mID=" + Convert.ToInt32(itemValue.Substring(0,itemValue.Length-1)) * 100 
                            + Convert.ToInt32(comboBoxEx7.Text.Split(new string[] { "-" }, StringSplitOptions.None)[0]);
                    else if (comboBoxEx7.Text == "ALL")
                        str += " and mID=" + Convert.ToInt32(comboBoxEx5.Text.Substring(0, comboBoxEx5.Text.Length - 1)) * 100
                            + Convert.ToInt32(itemValue);
                    else
                    {
                        str += " and mID=" + Convert.ToInt32(comboBoxEx5.Text.Substring(0, comboBoxEx5.Text.Length - 1)) * 100 
                            + Convert.ToInt32(comboBoxEx7.Text.Split(new string[] { "-" }, StringSplitOptions.None)[0]);
                    }
                    str += " and sID=" + sID;
                    break;
            }
            if (sourceTableName == "HST")
            {
                int index = Convert.ToInt32(comboBoxEx1.Text.Split(new Char[]{'-'})[0]) - 11;
                str += "and Flg=" + index;
            }
            return str;
        }
        //GEN数据写入
        private void writeGenHSTData(ref DataTable dt, string combox)
        {
            TreeStructure root = new TreeStructure(0);            
            CreateSummaryTable(root,dt,combox);

        }
        private void GenerateChildren(TreeStructure root)
        {
            DataView dv = UniVars.InDS.Tables["系统表"].DefaultView;
            dv.RowFilter="源节点ID="+root.ID+" and 节点类型>100 and 节点类型 < 200";
            for (int i = 0; i < dv.Count;i++ )
            {
                TreeStructure node = new TreeStructure(Convert.ToInt32(dv[i]["节点ID"]));
                node.Parent = root;
                root.Nodes.Add(node);
            }
        }
        private string GenerateGenIDs(List<int> types)
        {
            DataView dv=UniVars.InDS.Tables["系统表"].DefaultView;
            dv.RowFilter="节点类型 >=300 and 节点类型<400" ;
            string result="(";
            for (int i = 0; i < dv.Count; i++)
                if (types.Contains(Convert.ToInt32(dv[i]["节点类型"])))
                    result += i + ",";
            result = result.Substring(0, result.Length - 1);
            result+=")";
            return result;
        }
        private int MapIndexToSysID(int index)
        {
            DataView dv = UniVars.InDS.Tables["系统表"].DefaultView;
            dv.RowFilter="节点类型 >=300 and 节点类型<400";
            return Convert.ToInt32(dv[index]["节点ID"]);
        }
        private int AddRowToTable(DataTable dt,int id)
        {
            DataRow row = dt.NewRow();
            row[0] = id;
            for (int i = 1; i < dt.Columns.Count; i++)
                row[i] = 0;
            dt.Rows.Add(row);
            return dt.Rows.IndexOf(row);
        }
        private void AddRowsToTableByGenTypes(DataTable belongTable,TreeStructure curNode,DataRow sumRow,string combox, List<int> types)
        {
            DataView dv = new DataView();
            dv.Table = OutDS.Tables[sourceTableName];
            dv.RowFilter = PrepareFilterString(combox, curNode.ID + " and gID in " + GenerateGenIDs(types));
            for (int k = 0; k < dv.Count; k++)
            {
                DataRow row = belongTable.NewRow();
                for (int x = 0; x < belongTable.Columns.Count; x++)
                {
                    string[] columnPartNames = belongTable.Columns[x].ColumnName.Split(new string[] { "." }, StringSplitOptions.None);
                    row[x] = dv[k][columnPartNames[1]].ToString();
                    if (x != 0)
                        sumRow[x] = Convert.ToDouble(sumRow[x]) + Convert.ToDouble(row[x]);
                    else 
                        row[x] = MapIndexToSysID(Convert.ToInt32(row[x]));
                }
                belongTable.Rows.Add(row);
            }

        }
        private void AddChildDataToParent(DataTable dt,TreeStructure parent,TreeStructure child)
        {
            for(int i=0;i<5;i++)
                for(int j=1;j<dt.Columns.Count;j++)
                    dt.Rows[parent.RowIndex+i][j]=Convert.ToDouble(dt.Rows[parent.RowIndex+i][j])+
                        Convert.ToDouble(dt.Rows[child.RowIndex+i][j]);
        }
        private void ComputeSumOfAllGenTypes(DataTable dt, TreeStructure node)
        {
            for(int i=1;i<=4;i++)
                for(int j=1;j<dt.Columns.Count;j++)
                    dt.Rows[node.RowIndex][j] = Convert.ToDouble(dt.Rows[node.RowIndex][j]) +
                        Convert.ToDouble(dt.Rows[node.RowIndex + i][j]);

        }
        private void CreateSummaryTable(TreeStructure root, DataTable dt, string combox)
        {
            GenerateChildren(root);
            root.RowIndex = AddRowToTable(dt,root.ID);//总计
            AddRowToTable(dt,-1);//火电
            AddRowToTable(dt,-2);//水电
            AddRowToTable(dt,-3);//核电
            AddRowToTable(dt,-4);//新能源

            AddRowsToTableByGenTypes(dt, root, dt.Rows[root.RowIndex + 1], combox, new List<int>() { 300,301,302});
            AddRowsToTableByGenTypes(dt, root, dt.Rows[root.RowIndex + 2], combox, new List<int>() {  306 });
            AddRowsToTableByGenTypes(dt, root, dt.Rows[root.RowIndex + 3], combox, new List<int>() { 307, 308 });
            AddRowsToTableByGenTypes(dt, root, dt.Rows[root.RowIndex + 4], combox, new List<int>() { 309, 310});

            ComputeSumOfAllGenTypes(dt, root);
            foreach(TreeStructure node in root.Nodes)
            {
                CreateSummaryTable(node,dt,combox);
                AddChildDataToParent(dt,root,node);
            }
        }
        private string MapIDToName(string id)
        {
            string name = "";
            if (Convert.ToInt32(id) < 0)
                switch (Convert.ToInt32(id))
                {
                    case -1:
                        name = "  火电";
                        break;
                    case -2:
                        name = "  水电";
                        break;
                    case -3:
                        name = "  核电";
                        break;
                    case -4:
                        name = "  新能源";
                        break;
                }
            else
            {
                name = id + "-" + ProS_Assm.UniVars.InDS.Tables["系统表"].Select("节点ID=" + id)[0]["节点名称"].ToString();
            }
            return name;
        }

        private void AddNameColumnToTable(DataTable dt)
        {
            dt.Columns.Add("名  称");
            foreach(DataRow row in dt.Rows)
                row["名  称"] = MapIDToName(row[0].ToString());
        }
        //当sx=3时，combox为combobox3的值，当sx=5时，为combobox5的值
        private DataTable writeData(string fileName, ref DataTable dt, ref int xxu, string combox, int sx)
        {
            string pName = this.comboBoxEx3.Text;
            string[] ar1 = pName.Split(new string[] { "-" }, StringSplitOptions.None);
            string[] hh = comboBoxEx5.Text.Split(new string[] { "-" }, StringSplitOptions.None);

            DataView dv = new DataView();
            dv.Table = OutDS.Tables[sourceTableName];

            int sign = 0;
            if (sourceTableName == "GEN" || sourceTableName=="HST")
            {
                writeGenHSTData(ref dt, combox);
                return dt;
            }
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                string[] ar = dt.Rows[i][sign].ToString().Split(new string[] { "-" }, StringSplitOptions.None);
                switch (ar[0])
                {
                    case "PPL":
                    case "PLD":
                    case "ENS":
                    case "ENG":
                    case "TEC":
                    case "TRK":
                        dv.RowFilter = PrepareFilterString(combox,null);
                        for (int k = 0; k < dv.Count; k++)
                        {
                            if (ar[0] + "-" + dv[k]["Flg"].ToString() == dt.Rows[i][ar[0] + ".Flg"].ToString())
                            {
                                for (int x = 0; x < dt.Columns.Count; x++)
                                {
                                    string[] columnPartNames = dt.Columns[x].ColumnName.Split(new string[] { "." }, StringSplitOptions.None);
                                    if (columnPartNames[1] == "Flg")
                                        continue;
                                    dt.Rows[i][x] = dv[k][columnPartNames[1]].ToString();
                                }
                                break;
                            }
                        }
                        break;
                    case "HST":
                        break;
                    default:
                        MessageBox.Show("default!!!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        break;
                }
            }        
            return dt;
        }
        private void SysPart()
        {
            labelX6.Text = "系统及分区：";
            comboBoxEx3.Items.Clear();
            DataRow[] rows = UniVars.InDS.Tables["系统表"].Select("节点类型 >=100 and 节点类型 <200");
            int i = 0;
            foreach (DataRow row in rows)
            {
                comboBoxEx3.Items.Add(i + "-" + row["节点名称"].ToString());
                i++;
            }
            if (comboBoxEx3.Items.Count > 0)
                comboBoxEx3.SelectedIndex = 0;
        }
        //返回系统分区数目
        private int sysPart1()
        {
            foreach (object item in comboBoxEx3.Items)
                if (item.ToString()!="ALL")
                    this.comboBoxEx5.Items.Add(item.ToString()+"最大负荷日");
            return comboBoxEx3.Items.Count;
        }

        //读日类型，有2种的
        private void dayPart1(ComboBox comboBox)
        {
            comboBox.Items.Clear();
            comboBox.Items.Add("0-最大负荷日");
            comboBox.Items.Add("1-典型周");
            comboBox.Items.Add("ALL");
            comboBox.SelectedIndex = 0;
        }
        //读日类型，有7种的
        private void dayPart2(ComboBox comboBox)
        {
            comboBox.Items.Clear();
            DataRow[] rows = UniVars.InDS.Tables["系统表"].Select("节点类型 >=100 and 节点类型 <200");
            int i = 0;
            foreach (DataRow row in rows)
            {
                comboBox.Items.Add(i + "-" + row["节点名称"].ToString() + "最大负荷日");
                i++;
            }
            comboBox.Items.Add(i + "-周一");
            comboBox.Items.Add(i + "-周二");
            comboBox.Items.Add(i + "-周三");
            comboBox.Items.Add(i + "-周四");
            comboBox.Items.Add(i + "-周五");
            comboBox.Items.Add(i + "-周六");
            comboBox.Items.Add(i + "-周日");
            comboBox.Items.Add("ALL");
            comboBox.SelectedIndex = 0;
        }

        //读电站名称
        private void genPart(ComboBox comboBox)
        {
            comboBox.Items.Clear();
            DataRow[] rows = UniVars.InDS.Tables["系统表"].Select("节点类型 >=300 and 节点类型 <400");
            int i = 0;
            foreach (DataRow row in rows)
            {
                comboBox.Items.Add(i + "-" + row["节点名称"].ToString());
                i++;
            }
            if (comboBox.Items.Count > 0)
                comboBox.SelectedIndex = 0;
        }
        //读线路名称
        private void linePart(ComboBox comboBox,int index)
        {
            comboBox.Items.Clear();
            DataRow[] rows = null;
            if(index==3)
                rows=UniVars.InDS.Tables["系统表"].Select("节点类型 in (400,401) and IT01 = 0");
            else if(index==4)
                rows = UniVars.InDS.Tables["系统表"].Select("节点类型 in (400,401) and IT01 <> 0");
            else
                rows = UniVars.InDS.Tables["系统表"].Select("节点类型 >=100 and 节点类型 <200");

            int i = 0;
            foreach (DataRow row in rows)
            {
                comboBox.Items.Add(i + "-" + row["节点名称"].ToString());
                i++;
            }
            if (comboBox.Items.Count > 0)
                comboBox.SelectedIndex = 0;
        }
        private DataTable[] selectTable()
        {
            string fName = "";
            int lLength = 0;
            //其中d为所有方案表
            if (comboBoxEx2.Text == "ALL")
            {
                int count = comboBoxEx2.Items.Count - 1;
                DataTable[] d = readAll(count);
                for (int i = 0; i < count; i++)
                {
                    string name = comboBoxEx2.Items[i].ToString();
                    writeData(fName, ref d[i], ref lLength, name, 0);
                    d[i].TableName = readTabname1(name);
                    changeName(d[i], lLength);

                }
                return d;
            }
            //d为所有水平年的表
            else if (comboBoxEx4.Text == "ALL")
            {
                int count = comboBoxEx4.Items.Count - 1;
                DataTable[] d = readAll(count);
                for (int i = 0; i < count; i++)
                {
                    string name = comboBoxEx4.Items[i].ToString();
                    writeData(fName, ref d[i], ref lLength, name, 0);
                    d[i].TableName = readTabname1(name);
                    changeName(d[i], lLength);
                }
                return d;
            }

                //d为所有水文条件表
            else if (comboBoxEx6.Text == "ALL")
            {
                int count = comboBoxEx6.Items.Count - 1;
                DataTable[] d = readAll(count);
                for (int i = 0; i < count; i++)
                {
                    string name = comboBoxEx6.Items[i].ToString().Substring(0, 1);
                    writeData(fName, ref d[i], ref lLength, name, 0);
                    d[i].TableName = readTabname1(name);
                    changeName(d[i], lLength);
                }
                return d;
            }
            //d为所有分区
            else if (comboBoxEx3.Text == "ALL")
            {
                int count = comboBoxEx3.Items.Count - 1;
                DataTable[] d = readAll(count);
                for (int i = 0; i < count; i++)
                {
                    string j = comboBoxEx3.Items[i].ToString();
                    string[] xl = j.Split(new string[] { "-" }, StringSplitOptions.None);
                    writeData(fName, ref d[i], ref lLength, xl[0], 3);
                    d[i].TableName = readTabname1(xl[1]) + "^PPL^ ^ ^ ^单位：  MW/GW";
                    changeName(d[i], lLength);
                }
                return d;
            }
            //d为所有日类型
            else if (comboBoxEx5.Text == "ALL")
            {
                int count = comboBoxEx5.Items.Count - 1;
                DataTable[] d = readAll(count);
                for (int i = 0; i < count; i++)
                {
                    string j = comboBoxEx5.Items[i].ToString();
                    string[] xl = j.Split(new string[] { "-" }, StringSplitOptions.None);
                    writeData(fName, ref d[i], ref lLength, xl[0], 5);
                    d[i].TableName = readTabname1(j);
                    changeName(d[i], lLength);
                }
                return d;
            }
            else if (comboBoxEx7.Text == "ALL")
            {
                int count = comboBoxEx7.Items.Count - 1;
                DataTable[] d = readAll(count);
                for (int i = 0; i < count; i++)
                {
                    string j = comboBoxEx7.Items[i].ToString();
                    string[] xl = j.Split(new string[] { "-" }, StringSplitOptions.None);
                    writeData(fName, ref d[i], ref lLength, xl[0], 5);
                    d[i].TableName = readTabname1(j);
                    changeName(d[i], lLength);
                }
                return d;
            }
            else
            {
                DataTable[] d = readAll(1);
                DataTable dt = readData();
                int cc = dt.Rows.Count;
                int x = 0;
                dt = writeData(fName, ref dt, ref x, null, 0);
                dt.TableName = "Test_Sys^2010年^枯水年^Test_Sys最大负荷日^方案1^PPL^ ^ ^单位：  MW/GWh";//readTabname1(null);
                d[0] = dt;

                changeName(d[0], x);
                AddNameColumnToTable(d[0]);
                return d;
            }

        }
        //创建c个相同格式的数据表
        private DataTable[] readAll(int c)
        {
            DataTable[] dt = new DataTable[c];
            for (int i = 0; i < c; i++)
            {
                dt[i] = readData();
            }
            return dt;
        }

        //构建模板表
        private DataTable readData()
        {
            string templete = this.comboBoxEx1.Text;
            string[] arrStr1 = templete.Split(new string[] { "-" }, StringSplitOptions.None);

            DataTable dt = new DataTable();
            XmlDocument xmldoc = new XmlDocument();
            String a = Application.StartupPath + "\\TableViewConfig.xml";
            xmldoc.Load(Application.StartupPath + "\\TableViewConfig.xml");
            //得到顶层节点列表
            XmlNodeList topM = xmldoc.DocumentElement.ChildNodes;
            foreach (XmlNode element in topM)
            {
                if (element.Name.ToLower() == "templete")
                {
                    XmlNodeList nodelist = element.ChildNodes;
                    foreach (XmlNode el in nodelist)//读元素值
                    {
                        if (el.Name.ToLower() == "item" && el.Attributes["id"].Value.ToString().Equals(arrStr1[0]))
                        {
                            XmlNodeList nl = el.ChildNodes;
                            foreach (XmlNode ex in nl)
                            {
                                if (ex.Name.ToLower() == "columns")
                                {
                                    XmlNodeList nx = ex.ChildNodes;
                                    foreach (XmlNode xx in nx)
                                    {
                                        DataColumn myDataColumn;
                                        myDataColumn = new DataColumn();
                                        if (xx.Attributes["belongTableId"].Value.ToString() == "自定义")
                                        {

                                        }
                                        else
                                        {
                                            myDataColumn.ColumnName = xx.Attributes["belongTableId"].Value.ToString() + "." + xx.Attributes["refid"].Value.ToString();
                                            myDataColumn.DataType = Type.GetType("System.String");
                                        }
                                        dt.Columns.Add(myDataColumn);
                                    }
                                }
                                if (ex.Name.ToLower() == "rows")
                                {
                                    int sign = 0;
                                    for (int j = 0; j < dt.Columns.Count; j++)
                                    {
                                        string[] xx = dt.Columns[j].ColumnName.ToString().Split(new string[] { "." }, StringSplitOptions.None);
                                        if (xx[0] != "自定义" && xx[1] == "Flg")
                                        {
                                            sign = j;
                                            break;
                                        }
                                    }
                                    XmlNodeList nx = ex.ChildNodes;
                                    foreach (XmlNode xx in nx)
                                    {
                                        DataRow dr;
                                        dr = dt.NewRow();
                                        if (xx.Attributes["belongTableId"].Value.ToString() == "自定义")
                                        {

                                        }
                                        else
                                            dr[sign] = xx.Attributes["belongTableId"].Value.ToString() + "-" + xx.Attributes["refcodeId"].Value.ToString();
                                        dt.Rows.Add(dr);
                                    }
                                }
                            }
                        }
                    }
                }
            }


            return dt;
        }

        //读取标签名
        private string readTabname1(string tName)
        {
            string s = "";
            if (this.comboBoxEx3.Text.Equals("ALL"))
            {
                s += tName + "^";
            }
            else
            {
                string[] arrStr1 = this.comboBoxEx3.Text.Split(new string[] { "-" }, StringSplitOptions.None);
                s += arrStr1[1].Trim() + "^";
            }


            if (this.comboBoxEx4.Text.Equals("ALL"))
            {
                s += tName + "^";
            }
            else
            {
                s += this.comboBoxEx4.Text + "年" + "^";
            }


            if (this.comboBoxEx6.Text.Equals("ALL"))
            {
                s += tName + "^";
            }
            else
            {
                string[] arrStr = this.comboBoxEx6.Text.Split(new string[] { "-" }, StringSplitOptions.None);
                s += arrStr[arrStr.Length-1] + "^";
            }

            if (this.comboBoxEx5.Text.Equals("ALL"))
            {
                //s += "典型日";
                string[] nt = tName.Split(new string[] { "-" }, StringSplitOptions.None);
                s += nt[nt.Length-1] + "^";
            }
            else
            {
                string[] arrStr = this.comboBoxEx5.Text.Split(new string[] { "-" }, StringSplitOptions.None);
                s += arrStr[arrStr.Length-1] + "^";
            }
            if (this.comboBoxEx2.Text.Equals("ALL"))
            {
                s += "方案";
                s += tName + "^";
            }
            else
            {
                s += "方案";
                s += this.comboBoxEx2.Text + "^";
            }

            if (this.radioButton1.Checked) s += "单位：" + this.radioButton1.Text;
            if (this.radioButton2.Checked) s += "单位：" + this.radioButton2.Text;

            return s;
        }

        private void EnableConditionSelect(bool enable)
        {
            this.labelX1.Enabled = enable;
            this.labelX4.Enabled = enable;
            this.labelX5.Enabled = enable;
            this.labelX6.Enabled = enable;
            this.labelX7.Enabled = enable;
            this.labelX8.Enabled = enable;
            this.labelX9.Enabled = enable;
            this.textBoxX4.Enabled = enable;
            this.comboBoxEx2.Enabled = enable;
            this.comboBoxEx3.Enabled = enable;
            this.comboBoxEx4.Enabled = enable;
            this.comboBoxEx5.Enabled = enable;
            this.comboBoxEx6.Enabled = enable;
            this.comboBoxEx7.Enabled = enable;
            this.radioButton1.Enabled = enable;
            this.radioButton2.Enabled = enable;
        }

        private void comboBoxEx1_SelectedIndexChanged(object sender, EventArgs e)
        {
            ComboBoxEx cmb = sender as ComboBoxEx;
            if (cmb.SelectedIndex >= 0)
            {
                this.buttonX3.Enabled = true;
                EnableConditionSelect(true);
                String templateName = cmb.Text;
                string[] arrStr1 = templateName.Split(new string[] { "-" }, StringSplitOptions.None);
                this.textBoxX4.Text = arrStr1[1];
                sourceTableName = this.findOriginal(arrStr1[0].Trim());
                this.combChange(sourceTableName);
            }
        }

        private void comboBoxEx2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBoxEx2.Text != "")
            {
                comboBoxEx4.Items.Clear();
                DataView dv = new DataView();
                dv.Table = OutDS.Tables[sourceTableName];
                if (comboBoxEx2.Text != "ALL")
                    dv.RowFilter = "Prj=" + this.comboBoxEx2.Text;
                DataTable distinctValues = dv.ToTable(true, "Yrs");
                foreach (DataRow row in distinctValues.Rows)
                    comboBoxEx4.Items.Add(row[0].ToString());
                if (comboBoxEx4.Items.Count > 0)
                {
                    comboBoxEx4.Items.Add("ALL");
                    comboBoxEx4.SelectedIndex = 0;
                }
            }
        }

        private void comboBoxEx4_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBoxEx4.Text != "")
            {
                comboBoxEx6.Items.Clear();
                DataView dv = new DataView();
                dv.Table = OutDS.Tables[sourceTableName];
                if (comboBoxEx2.Text != "ALL")
                {
                    dv.RowFilter = "Prj=" + this.comboBoxEx2.Text;
                    if(comboBoxEx4.Text!="ALL")
                        dv.RowFilter+=" and Yrs=" + this.comboBoxEx4.Text; ;
                }
                DataTable distinctValues = dv.ToTable(true, "Hyd");
                foreach (DataRow row in distinctValues.Rows)
                {
                    string str = row[0].ToString();
                    switch (str)
                    {
                        case "1":
                            str += "-枯水年";
                            break;
                        default:
                            str += "-其他";
                            break;
                    }
                    comboBoxEx6.Items.Add(str);
                }
                if (comboBoxEx6.Items.Count > 0)
                {
                    comboBoxEx6.Items.Add("ALL");
                    comboBoxEx6.SelectedIndex = 0;
                }
            }
        }

        private void comboBoxEx6_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBoxEx3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBoxEx5_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBoxEx7_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void buttonX3_Click(object sender, EventArgs e)
        {            
            this.Visible = false;
            TableView tableView = new TableView();
            ExcelRead read = new ExcelRead(this.selectTable);
            Thread thdSub = new Thread(new ThreadStart(this.progressB));
            thdSub.Start();
            IAsyncResult result = read.BeginInvoke(AddComplete, null);
            DataTable[] mytable = read.EndInvoke(result);
            tableView.newTab(mytable);
            tableView.Owner = this;
            tableView.StartPosition = FormStartPosition.CenterScreen;
            tableView.parentForm = this;
            tableView.ShowDialog();
        }

        private void buttonX4_Click(object sender, EventArgs e)
        {
            this.Visible = false;
        }

        private void buttonX1_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Title = "打开现有 LPSP_ProS 输入数据库文件";
            dlg.Filter = "Xml文件 |*.xml|所有文件|*.*";
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                string filename = dlg.FileName.Split(new Char[] { '.'})[0];
                if (System.IO.File.Exists(filename + "_RST.xml") &&
                    System.IO.File.Exists(filename + "_MAP.xml") &&
                    System.IO.File.Exists(filename + "_GEN.xml"))
                {
                    UniVars.mOutFile = filename;
                    this.textBoxX1.Text = filename;
                    ReadOutFiles();
                }
                else
                    MessageBox.Show("错误的输出文件龚永明！", "提示信息", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

    }
    public class TreeStructure : Object
    {
        public List<TreeStructure> Nodes = new List<TreeStructure>();
        public TreeStructure Parent = null;
        public int RowIndex=-1;
        public int ID;
        public TreeStructure(int id)
        {
            ID = id;
        }
        public TreeStructure()
        {
            ID = -1;
        }
    }

}
